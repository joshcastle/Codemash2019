import sys
import io
import can
import time

#create the bus object from socketcan
bus = can.interface.Bus(bustype='socketcan', channel='can0')

def send_message():
    for i in range (0x1, 0x20):
        msg = can.Message(arbitration_id=0x123, data = [2, i, i, 0, 0, 0, 0, 0])
        bus.send(msg)
        time.sleep(0.1)

while True:
    send_message()
