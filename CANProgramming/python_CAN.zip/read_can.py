import sys
import io
import can
import time

#can bus initialization

bus = can.interface.Bus(bustype='socketcan', channel='can0')

#create buffered reader to queue and read CAN messages
canBR = can.BufferedReader() #create the buffered BufferedReader
can.Notifier(bus, [canBR]) #associates the buffered reader with the bus obj

while True:
    msg = canBR.get_message(timeout=1)
    #if "timeout" then msg will be "None"
    print (msg)
